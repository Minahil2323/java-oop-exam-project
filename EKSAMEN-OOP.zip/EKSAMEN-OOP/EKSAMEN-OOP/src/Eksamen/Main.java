package Eksamen;

public class Main {
    public static void main(String[] args) {
        // Starter hele applikasjonen ved å kjøre menyprogrammet som håndterer
        // Brukerens valg. Dette inkluderer både del 1 og del 2 av eksamen.

        new MenuProgram().run();

    }
}





